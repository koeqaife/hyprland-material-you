from __future__ import annotations

from pathlib import Path
import os
from config import APP_CACHE_DIR, CACHE_DIR
from utils.logger import logger
from utils.ref import Ref

TEMP_PATH = os.path.join(APP_CACHE_DIR, "cliphist")
items = Ref[dict[str, str]]({}, name="cliphist_items")


def get() -> dict[str, str]:
    import subprocess
    try:
        result = subprocess.run(
            ["cliphist", "list"],
            capture_output=True,
            text=True,
            check=True,
            encoding="utf-8",
        )
    except subprocess.CalledProcessError:
        return {}

    lines = result.stdout.strip().splitlines()[:250]

    return {
        id_.strip(): content.strip()
        for line in lines
        if (parts := line.split(maxsplit=1)) and len(parts) == 2
        for id_, content in [parts]
    }


def repopulate() -> None:
    history = get()
    history_keys = set(history.keys())
    existing_keys = set(items.value.keys())

    new_keys = history_keys - existing_keys
    removed_keys = existing_keys - history_keys

    if not new_keys and not removed_keys:
        return

    items.block_changed()

    for key in new_keys:
        items.value[key] = history[key]

    for key in removed_keys:
        del items.value[key]

    items.unblock_changed()
    items.notify_signal("changed", items.value)


def copy_by_id(item_id: str) -> None:
    import subprocess
    with subprocess.Popen(
        ["cliphist", "decode", item_id], stdout=subprocess.PIPE
    ) as decode_proc, subprocess.Popen(
        ["wl-copy"], stdin=decode_proc.stdout
    ):
        if decode_proc.stdout:
            decode_proc.stdout.close()


def secure_clear() -> None:
    import subprocess
    db_path = os.path.join(CACHE_DIR, "cliphist/db")
    if os.path.exists(db_path):
        subprocess.run(["shred", "-u", db_path], check=True)
    else:
        if __debug__:
            logger.debug("Cliphist db file not found, skipping shred.")


def clear() -> None:
    import subprocess
    subprocess.run(["cliphist", "wipe"], check=True)


def save_cache_file(item_id: str) -> str:
    import subprocess
    output_file = Path(f"{TEMP_PATH}/{item_id}.png")
    output_file.parent.mkdir(parents=True, exist_ok=True)

    if not output_file.exists():
        with subprocess.Popen(
            ["cliphist", "decode", item_id], stdout=subprocess.PIPE
        ) as decode_proc, open(output_file, "wb") as file:
            if decode_proc.stdout:
                file.write(decode_proc.stdout.read())

    return str(output_file)


def clear_tmp() -> None:
    tmp_dir = Path(TEMP_PATH)
    for file in tmp_dir.glob("*"):
        file.unlink()
