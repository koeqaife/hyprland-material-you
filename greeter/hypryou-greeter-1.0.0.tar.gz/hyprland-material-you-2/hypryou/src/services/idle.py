from __future__ import annotations
import asyncio
import os
from config import ASSETS_DIR
from utils.service import Service
from repository import gio, glib
from utils.logger import logger
import typing as t
from pywayland.client.display import Display
from pywayland.protocol.wayland.wl_seat import WlSeat
from pywayland.protocol.ext_idle_notify_v1.ext_idle_notifier_v1 import (
    ExtIdleNotifierV1, ExtIdleNotifierV1Proxy as Notifier
)
from src.services import hyprland
from src.services.upower import get_upower, BatteryState
from src.services.state import is_locked, is_idle_locked
from src.services.login1 import get_login_manager
from src.services.mpris import players
from config import Settings

if t.TYPE_CHECKING:
    from pywayland.protocol.wayland.wl_registry import WlRegistryProxy
    from pywayland.protocol.ext_idle_notify_v1.ext_idle_notification_v1 import (  # noqa: E501
        ExtIdleNotificationV1Proxy as Notification
    )


WATCHER_XML_PATH = os.path.join(
    ASSETS_DIR, "dbus", "org.freedesktop.ScreenSaver.xml"
)
BUS_WATCHER = "org.freedesktop.ScreenSaver"
PATH_WATCHER = "/org/freedesktop/ScreenSaver"

SETTINGS_KEYS = (
    "idle.ac.lock", "idle.ac.dpms", "idle.ac.sleep",
    "idle.battery.lock", "idle.battery.dpms", "idle.battery.sleep"
)


class ScreenSaver:
    def __init__(self) -> None:
        upower = get_upower()
        self._conn: gio.DBusConnection | None = None
        self.items: dict[int, tuple[str, str]] = {}
        self.next_id = 100
        self.last_battery_state = upower.state

        self.display = Display()
        self.display.connect()
        self.registry: "WlRegistryProxy" = self.display.get_registry()
        self.idle_notifier: Notifier | None = None
        self.seat: WlSeat | None = None
        self.notifications: list["Notification"] = []
        self.notifier_set = False

    def on_settings_changed(self, key: str, value: str) -> None:
        if key in SETTINGS_KEYS:
            self.update_notifications()

    def on_event(self, *args: t.Any) -> bool:
        self.display.dispatch()
        self.display.roundtrip()
        self.display.roundtrip()
        return True

    def register(self) -> int:
        return gio.bus_own_name(
            gio.BusType.SESSION,
            BUS_WATCHER,
            gio.BusNameOwnerFlags.NONE,
            self.on_bus_acquired,
            self.on_name_acquired,
            lambda *_: logger.warning(
                "Another screen saver is running"
            )
        )

    def on_name_acquired(self, *args: t.Any) -> None:
        self.fd = self.display.get_fd()
        self.registry.dispatcher["global"] = self.global_handler
        self.display.dispatch()
        self.display.roundtrip()
        self.display.roundtrip()
        glib.io_add_watch(  # type: ignore
            self.fd, glib.IO_IN, self.on_event
        )

        get_upower().watch(
            "changed", self.update_on_battery
        )
        Settings()._signals.watch("changed", self.on_settings_changed)

    def create_idle_notification(
        self,
        timeout: int,
        on_idle: t.Callable[["Notification"], None],
        on_resume: t.Callable[["Notification"], None] | None = None
    ) -> None:
        if timeout == 0:
            return
        if self.idle_notifier is None:
            logger.critical("IdleNotifier proxy is None")
            return
        timeout *= 1000
        notification: "Notification" = (
            self.idle_notifier.get_idle_notification(
                timeout=timeout, seat=self.seat
            )
        )
        self.notifications.append(notification)
        notification.dispatcher["idled"] = on_idle
        if on_resume is not None:
            notification.dispatcher["resumed"] = on_resume

    @property
    def is_inhibited(self) -> bool:
        login1 = get_login_manager()
        return login1.is_idle_inhibited() or bool(self.items)

    def dpms_off(self, *args: t.Any) -> None:
        if __debug__:
            logger.debug(
                "Idle: Turning off screen"
            )
        if self.is_inhibited:
            if __debug__:
                logger.debug("Is inhibited!")
            return
        asyncio.create_task(hyprland.client.raw("dispatch dpms off"))

    def dpms_on(self, *args: t.Any) -> None:
        if __debug__:
            logger.debug(
                "Idle: Turning on screen"
            )
        asyncio.create_task(hyprland.client.raw("dispatch dpms on"))

    def on_lock(self, *args: t.Any) -> None:
        if __debug__:
            logger.debug(
                "Idle: Locking screen"
            )
        if self.is_inhibited:
            if __debug__:
                logger.debug("Is inhibited!")
            return
        is_idle_locked.value = True
        is_locked.value = True

    def on_sleep(self, *args: t.Any) -> None:
        if __debug__:
            logger.debug(
                "Idle: Sleep"
            )
        login1 = get_login_manager()
        if login1.can_sleep() and not self.is_inhibited:
            for player in players.value.values():
                player.pause()
            login1.suspend()
        elif __debug__:
            logger.debug("Is inhibited!")

    def update_on_battery(self, *args: t.Any) -> None:
        upower = get_upower()
        if self.last_battery_state != upower.state:
            self.update_notifications()
            self.last_battery_state = upower.state

    def update_notifications(self) -> None:
        if self.notifications:
            for notification in self.notifications:
                try:
                    resumed_cb = notification.dispatcher["resumed"]
                    if resumed_cb:
                        if __debug__:
                            logger.debug(
                                "Calling on_resumed manually before destroy"
                            )
                        resumed_cb(notification)
                finally:
                    notification.destroy()
            self.notifications.clear()

        settings = Settings()
        upower = get_upower()

        base_view = settings.get_view_for("idle")
        if not upower.is_battery or upower.state != BatteryState.DISCHARGING:
            view = base_view.get_view_for("ac")
        else:
            view = base_view.get_view_for("battery")

        lock_timeout = view.get("lock")
        dpms_timeout = view.get("dpms")
        sleep_timeout = view.get("sleep")

        if __debug__:
            logger.debug("Lock timeout: %d", lock_timeout)
            logger.debug("Dpms timeout: %d", dpms_timeout)
            logger.debug("Sleep timeout: %d", sleep_timeout)
        if lock_timeout > 0:
            self.create_idle_notification(
                lock_timeout,
                self.on_lock
            )
        if dpms_timeout > 0:
            self.create_idle_notification(
                lock_timeout + dpms_timeout,
                self.dpms_off,
                self.dpms_on
            )
        if sleep_timeout > 0:
            self.create_idle_notification(
                lock_timeout + dpms_timeout + sleep_timeout,
                self.on_sleep,
                self.dpms_on
            )

    def global_handler(
        self,
        registry: "WlRegistryProxy",
        name: int,
        interface: str,
        version: int
    ) -> None:
        if interface == "wl_seat":
            self.seat = registry.bind(name, WlSeat, version)
        elif interface == "ext_idle_notifier_v1":
            self.idle_notifier = registry.bind(
                name, ExtIdleNotifierV1, version
            )

        if self.seat and self.idle_notifier and not self.notifier_set:
            self.update_notifications()
            self.notifier_set = True

    def on_bus_acquired(
        self, conn: gio.DBusConnection, name: str, user_data: object = None
    ) -> None:
        if __debug__:
            logger.debug("Screen saver bus acquired")
        self._conn = conn

        with open(WATCHER_XML_PATH) as f:
            watcher_xml = f.read()
        node_info = gio.DBusNodeInfo.new_for_xml(watcher_xml)
        ifaces = node_info.interfaces

        for interface in ifaces:
            if interface.name == name:
                if __debug__:
                    logger.debug("Registering interface '%s'", name)
                conn.register_object(
                    PATH_WATCHER,
                    interface,
                    self.handle_bus_call
                )

    def handle_bus_call(
        self,
        conn: gio.DBusConnection,
        sender: str,
        path: str,
        interface: str,
        target: str,
        params: glib.Variant,
        invocation: gio.DBusMethodInvocation,
        user_data: t.Any = None,
    ) -> None:
        match target:
            case "Get":
                invocation.return_value(None)
            case "GetAll":
                invocation.return_value(glib.Variant("a{sv}", ()))
            case "Inhibit":
                cookie = self.inhibit(*params.unpack())
                invocation.return_value(glib.Variant("(u)", (cookie,)))
            case "UnInhibit":
                cookie = t.cast(int, params.unpack()[0])
                self.un_inhibit(cookie)
                invocation.return_value(None)

        return conn.flush()

    def un_inhibit(self, cookie: int) -> None:
        if cookie not in self.items.keys():
            return
        if __debug__:
            logger.debug(
                "ScreenSaver UnInhibit: App: '%s' Cookie: '%s'",
                self.items[cookie][0], cookie
            )
        del self.items[cookie]

    def inhibit(self, app_name: str, reason: str) -> int:
        cookie = self.next_id
        self.next_id += 1
        self.items[cookie] = (app_name, reason)
        if __debug__:
            logger.debug(
                "ScreenSaver Inhibit: App: '%s' Reason: '%s' Cookie: %s",
                app_name, reason, cookie
            )
        return cookie


class ScreenSaverService(Service):
    def __init__(self) -> None:
        self.watcher: ScreenSaver

    def app_init(self) -> None:
        self.watcher = ScreenSaver()

    def start(self) -> None:
        if __debug__:
            logger.debug("Starting screen saver dbus")
        self.watcher.register()

    def on_close(self) -> None:
        if not getattr(self, "watcher", None):
            return
        for notification in self.watcher.notifications:
            notification.destroy()
