from repository import gtk, glib
from utils.ref import Ref
import typing as t
from src.services.state import close_window, open_window, open_settings
from src import widget


def open_hyprpicker(*_: t.Any) -> None:
    import subprocess

    def start() -> None:
        subprocess.Popen(
            ["hyprpicker", "-a"],
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL
        )
    close_window("sidebar")
    glib.timeout_add(500, start)


def open_power_menu(*_: t.Any) -> None:
    close_window("sidebar")
    open_window("power_menu")


def _open_settings(*_: t.Any) -> None:
    open_settings()
    close_window("sidebar")


class ActionButton(gtk.Button):
    __gtype_name__ = "SidebarActionButton"

    def __init__(
        self,
        icon: str | Ref[str],
        on_click: t.Callable[..., None]
    ) -> None:
        super().__init__(
            css_classes=("action-button", "icon-outlined"),
            hexpand=True
        )
        self.icon = widget.Icon(icon)
        self.set_child(self.icon)
        self.conn = self.connect("clicked", on_click)

    def destroy(self) -> None:
        self.disconnect(self.conn)
        self.icon.destroy()


class Actions(gtk.Box):
    __gtype_name__ = "SidebarActionsBox"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("action-buttons",),
            hexpand=True
        )
        self.color_picker = ActionButton(
            "colorize", open_hyprpicker
        )
        self.power = ActionButton(
            "power_settings_new", open_power_menu
        )
        self.settings = ActionButton(
            "settings", _open_settings
        )
        self.children = (
            self.color_picker,
            self.power,
            self.settings
        )
        for child in self.children:
            self.append(child)

    def destroy(self) -> None:
        for child in self.children:
            child.destroy()
            self.remove(child)
