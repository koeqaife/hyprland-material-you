from repository import gtk, gdk, pango, bluetooth, layer_shell, glib
from dataclasses import dataclass
from utils.ref import Ref
from utils.styles import toggle_css_class
from utils.format import escape_markup
from utils.logger import logger
from utils.system import parse_xkb_layouts
from utils import format, downloader
import asyncio
from time import perf_counter
from config import Settings
import weakref
import cairo
from src.services.network import get_network
from src.services.state import toggle_window, open_settings, _opened_windows
from src.services.upower import get_upower, BatteryLevel, BatteryState
from src.services.backlight import get_backlight_manager, BacklightDeviceView
from src.services.clock import date, full_date, time
from src.services.apps import launch_detached
from src.services import hyprland
from src.services.hyprland import active_workspace, workspace_ids
from src.services.hyprland import monitor_ids
from src.services.hyprland import active_layout, show_layout
from src.services.mpris import MprisPlayer, current_player
from src.services import audio
from src import widget
import typing as t


dummy_region = cairo.Region()


class WorkspaceButton(gtk.Button):
    __gtype_name__ = "HyprlandWorkspaceButton"

    def __init__(self, id: int) -> None:
        super().__init__(
            css_classes=("workspace",),
            valign=gtk.Align.CENTER,
            halign=gtk.Align.CENTER,
            label=str(id)
        )

        self.id = id

        self.connected = self.connect("clicked", self.on_clicked)

    def on_clicked(self, *args: t.Any) -> None:
        asyncio.create_task(hyprland.client.dispatch(f"workspace {self.id}"))

    def destroy(self) -> None:
        self.disconnect(self.connected)


class Workspaces(gtk.Box):
    __gtype_name__ = "HyprlandWorkspaces"

    def __init__(
        self,
        monitor: gdk.Monitor,
        monitor_id: int
    ) -> None:
        self.settings = Settings()
        self.monitor = monitor
        self.monitor_id = monitor_id
        super().__init__(
            css_classes=("workspaces",),
            valign=gtk.Align.CENTER
        )

        self._old_active = 0

        self.buttons: dict[int, WorkspaceButton] = {}
        self.hide_empty = self.settings.get("hide_empty_workspaces")

        self.update_buttons()

        self.ref_handlers: dict[Ref[t.Any], int] = {
            active_workspace: active_workspace.watch(self.update_active),
            workspace_ids: workspace_ids.watch(self.update_empty),
            monitor_ids: monitor_ids.watch(self.update_buttons)
        }
        self.settings_handlers = (
            self.settings.watch(
                "separated_workspaces", self.update_buttons, False
            ),
            self.settings.watch(
                "hide_empty_workspaces", self.on_hide_empty, False
            ),
        )

        self._last_scroll = 0.0
        self._scroll = gtk.EventControllerScroll.new(
            gtk.EventControllerScrollFlags.VERTICAL
        )
        self._scroll_connection = self._scroll.connect(
            "scroll", self.on_scroll
        )
        self.add_controller(self._scroll)

    def on_hide_empty(self, new_value: bool) -> None:
        self.hide_empty = new_value
        self.update_empty(workspace_ids.value)

    def update_buttons(self, *args: t.Any) -> None:
        if self.buttons:
            for button in self.buttons.values():
                button.destroy()
                self.remove(button)
            self.buttons.clear()
        if self._old_active:
            self._old_active = 0
        monitor_id = monitor_ids.value.get(
            self.monitor.get_connector(),
            self.monitor_id
        )
        monitor_multiplier = (
            monitor_id + 1
            if self.settings.get("separated_workspaces")
            else 1
        )

        for workspace in (
            range(10 * (monitor_multiplier - 1), 10 * monitor_multiplier)
        ):
            self.buttons[workspace + 1] = WorkspaceButton(workspace + 1)

        for button in self.buttons.values():
            self.append(button)

        self.update_active(active_workspace.value)
        self.update_empty(workspace_ids.value)

    def destroy(self) -> None:
        for button in self.buttons.values():
            button.destroy()
            self.remove(button)
        self.buttons.clear()

        self._scroll.disconnect(self._scroll_connection)
        self.remove_controller(self._scroll)

        for handler in self.settings_handlers:
            self.settings.unwatch(handler)

        self._scroll = None  # type: ignore
        for ref, handler_id in self.ref_handlers.items():
            ref.unwatch(handler_id)

    def on_scroll(
        self,
        controller: gtk.EventControllerScroll,
        dx: float,
        dy: float
    ) -> None:
        now = perf_counter()
        if self._last_scroll < now - 0.25:
            self._last_scroll = now
            action = "+1" if dy < 0 else "-1"
            asyncio.create_task(
                hyprland.client.dispatch(f"workspace {action}")
            )

    def update_active(
        self,
        new_value: int
    ) -> None:
        if not new_value:
            return
        if self._old_active == new_value:
            return
        if self._old_active in self.buttons.keys():
            toggle_css_class(self.buttons[self._old_active], "active", False)
            self._old_active = new_value
        else:
            self._old_active = new_value
        if new_value not in self.buttons.keys():
            return
        toggle_css_class(self.buttons[new_value], "active", True)

    def update_empty(
        self,
        not_empty: set[int]
    ) -> None:
        for button in self.buttons.values():
            is_empty = button.id not in not_empty
            toggle_css_class(button, "empty", is_empty)
            if self.hide_empty:
                button.set_visible(not is_empty)
            else:
                button.set_visible(True)


class Clock(gtk.Button):
    __gtype_name__ = "ClockApplet"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("clock", "bar-applet"),
            label=time.value
        )

        self.ref_handlers = {
            time: time.watch(self.update_time),
            # We know that clock.date is updated as well
            # Cause Signals uses glib.idle_add
            # And just for case we watch full_date
            # as it's updated after clock.date
            full_date: full_date.watch(self.update_date)
        }
        self.handler = self.connect("clicked", self.on_click)

    def on_click(self, *args: t.Any) -> None:
        toggle_window("calendar")

    def update_time(self, new: str) -> None:
        self.set_label(new)

    def update_date(self, *args: t.Any) -> None:
        self.set_tooltip_text(
            f"{full_date.value}\n{date.value}"
        )

    def destroy(self) -> None:
        self.disconnect(self.handler)
        for ref, handler_id in self.ref_handlers.items():
            ref.unwatch(handler_id)


@dataclass
class LastChanged:
    artist: str | None = None
    title: str | None = None
    artUrl: str | None = None
    playback_status: str | None = None
    can_go_prev: bool | None = None
    can_go_next: bool | None = None
    can_pause: bool | None = None


class Player(gtk.Box):
    __gtype_name__ = "MprisPlayer"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("mpris-player", "bar-applet"),
            halign=gtk.Align.START,
            valign=gtk.Align.CENTER
        )
        self.settings = Settings()

        self.player_handlers: dict[MprisPlayer, int] = {}

        self.icon = widget.Icon(
            "music_note",
            visible=True,
            css_classes=("player-icon",)
        )

        self.image = gtk.Box(
            css_classes=("image",),
            valign=gtk.Align.CENTER,
            halign=gtk.Align.CENTER,
            visible=False
        )

        self.label = gtk.Label(
            ellipsize=pango.EllipsizeMode.END,
            max_width_chars=20,
            halign=gtk.Align.CENTER,
            hexpand=True,
            use_markup=True
        )

        self.btn_box = gtk.Box(
            css_classes=("buttons",),
            valign=gtk.Align.CENTER,
            halign=gtk.Align.CENTER
        )

        icons = ["skip_previous", "pause", "skip_next"]
        classes = ["previous", "play-pause", "next"]
        handlers = [self.previous, self.play_pause, self.next]

        self.buttons: list[gtk.Button] = []
        self.conns: dict[gtk.Button, int] = {}

        for icon, css_class, handler in zip(icons, classes, handlers):
            btn = gtk.Button(
                child=widget.Icon(icon),
                css_classes=(css_class,)
            )
            self.btn_box.append(btn)
            self.conns[btn] = btn.connect("clicked", handler)
            self.buttons.append(btn)

        self.children = (
            self.icon,
            self.image,
            self.label,
            self.btn_box
        )

        for child in self.children:
            self.append(child)

        self.image_provider = gtk.CssProvider()
        self.image.get_style_context().add_provider(
            self.image_provider,
            gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

        self.last_changed = LastChanged()
        self.cur_player_handler = current_player.watch(self.on_changed)
        self.on_changed()

        self.click_gesture = gtk.GestureClick.new()
        self.click_gesture.set_button(0)
        self.gesture_conn = (
            self.click_gesture.connect("released", self.on_click_released)
        )
        self.setting_handlers: tuple[int] = (
            self.settings.watch("bar_media_style", self.on_changed, False),
        )
        self.add_controller(self.click_gesture)

    def use_image(self, value: bool) -> None:
        self.image.set_visible(value)
        self.icon.set_visible(not value)

    def on_click_released(
        self,
        gesture: gtk.GestureClick,
        n_press: int,
        x: int,
        y: int
    ) -> None:
        button_number = gesture.get_current_button()
        if button_number == gdk.BUTTON_PRIMARY:
            toggle_window("players")
        elif button_number == gdk.BUTTON_SECONDARY:
            self.play_pause()

    def next(self, *args: t.Any) -> None:
        current = self.get_player()
        if current:
            current.next()

    def previous(self, *args: t.Any) -> None:
        current = self.get_player()
        if current:
            current.previous()

    def play_pause(self, *args: t.Any) -> None:
        current = self.get_player()
        if current:
            current.play_pause()

    def get_player(self) -> MprisPlayer | None:
        if len(current_player.value) == 2:
            return current_player.value[1]
        else:
            return None

    def update_buttons(self) -> None:
        current = self.get_player()
        if not current or self.settings.get("bar_media_style") == 2:
            self.btn_box.set_visible(False)
            self.last_changed.can_go_prev = None
            self.last_changed.can_go_next = None
            self.last_changed.can_pause = None
            self.last_changed.playback_status = None
        else:
            last_changed = self.last_changed

            playback_status = current.playback_status
            can_go_prev = current.can_go_previous
            can_go_next = current.can_go_next
            can_pause = current.can_pause

            if playback_status != last_changed.playback_status:
                icon = self.buttons[1].get_child()
                if isinstance(icon, gtk.Label):
                    icon.set_label(
                        "pause" if playback_status == "Playing"
                        else "play_arrow"
                    )
                    last_changed.playback_status = playback_status

            if can_go_prev != last_changed.can_go_prev:
                self.buttons[0].set_visible(can_go_prev)
                last_changed.can_go_prev = can_go_prev

            if can_go_next != last_changed.can_go_next:
                self.buttons[2].set_visible(can_go_next)
                last_changed.can_go_next = can_go_next

            if can_pause != last_changed.can_pause:
                self.buttons[1].set_visible(can_pause)
                last_changed.can_pause = can_pause

            self.btn_box.set_visible(
                can_pause or can_go_next or can_go_prev
            )

    def update_label(self) -> None:
        if self.settings.get("bar_media_style") == 2:
            self.label.set_visible(False)
            return
        else:
            self.label.set_visible(True)

        current = self.get_player()
        if not current:
            text = "Nothing's playing"
            self.last_changed.title = None
            self.last_changed.artist = None
        else:
            metadata = current.metadata

            xesam_artist = metadata.get("xesam:artist")
            artist = xesam_artist[0] if xesam_artist else None
            title = metadata.get("xesam:title")

            if (
                not artist
                or not title
                or self.settings.get("bar_media_style") == 1
            ):
                text = current.get_bus_name().split(".")[3].capitalize()
                self.last_changed.title = None
                self.last_changed.artist = None
            else:
                if (
                    artist == self.last_changed.artist
                    and title == self.last_changed.title
                ):
                    return

                self.last_changed.title = title
                self.last_changed.artist = artist

                artist = escape_markup(artist)
                title = escape_markup(title)
                # we show title first cuz length of label is limited
                text = f"{title} <i>- {artist}</i>"
        self.set_tooltip_markup(text)
        self.label.set_label(text)

    def on_download(self, filepath: str | None) -> None:
        if not self.children:
            return
        if not filepath:
            self.use_image(False)
            return
        self.use_image(True)
        css = f"box {{ background-image: url('file://{filepath}'); }}"
        self.image_provider.load_from_data(css)

    def update_image(self) -> None:
        if self.settings.get("bar_media_style") == 2:
            self.use_image(False)
            self.last_changed.artUrl = None
            current = self.get_player()
            if current:
                self.icon.set_label(
                    "pause" if current.playback_status == "Playing"
                    else "play_arrow"
                )
            else:
                self.icon.set_label("music_note")
            return

        if len(current_player.value) != 2:
            # Hiding both for better looking
            self.image.set_visible(False)
            self.icon.set_visible(False)
            self.last_changed.artUrl = None
        else:
            assert current_player.value
            metadata = current_player.value[1].metadata
            art_url = metadata.get("mpris:artUrl")
            if not art_url or self.settings.get("bar_media_style") == 1:
                self.use_image(False)
                self.last_changed.artUrl = None
                self.icon.set_label("music_note")
                return
            if art_url == self.last_changed.artUrl:
                return

            self.use_image(False)
            self.last_changed.artUrl = art_url
            downloader.download_image_async(
                art_url, self.on_download, (24, 24), "arts"
            )

    def update_all(self) -> None:
        self.update_image()
        self.update_label()
        self.update_buttons()
        toggle_css_class(
            self,
            "collapsed",
            self.settings.get("bar_media_style") == 2
        )

    def update_watcher(self) -> None:
        current = self.get_player()
        if not current:
            return

        for player, handler in list(self.player_handlers.items()):
            if player is not current:
                player.unwatch(handler)
                del self.player_handlers[player]

        if current not in self.player_handlers.keys():
            handler_id = current.watch("changed", self.on_changed)
            self.player_handlers[current] = handler_id

    def on_changed(self, *args: t.Any) -> None:
        self.update_watcher()
        self.update_all()

    def destroy(self) -> None:
        for player, handler in self.player_handlers.items():
            player.unwatch(handler)

        for btn in self.buttons:
            btn_child = btn.get_child()
            if isinstance(btn_child, widget.Icon):
                btn_child.destroy()
            btn.set_child(None)
            self.btn_box.remove(btn)
        for child in self.children:
            self.remove(child)
        for _widget, conn in self.conns.items():
            _widget.disconnect(conn)

        self.click_gesture.disconnect(self.gesture_conn)
        self.remove_controller(self.click_gesture)
        current_player.unwatch(self.cur_player_handler)

        for handler_id in self.setting_handlers:
            self.settings.unwatch(handler_id)

        self.children = None  # type: ignore
        self.buttons = None  # type: ignore
        self.click_gesture = None  # type: ignore
        self.image_provider = None  # type: ignore


class KeyboardLayout(gtk.Label):
    __gtype_name__ = "KeyboardLayoutApplet"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("keyboard-layout", "bar-applet")
        )

        self.update_layout(active_layout.value)
        self.set_visible(show_layout.value)

        self.handlers: dict[Ref[t.Any], int] = {
            show_layout: show_layout.watch(self.update_visible),
            active_layout: active_layout.watch(self.update_layout)
        }

    def update_visible(self, new_value: bool) -> None:
        self.set_visible(new_value)

    def update_layout(self, new_layout: str) -> None:
        code_name = parse_xkb_layouts().get(  # parse_xkb_layouts has lru_cache
            new_layout,
            format.get_layout_tag(new_layout)  # Just in case
        )
        self.set_label(code_name)
        self.set_tooltip_text(new_layout)

    def destroy(self) -> None:
        for ref, handler_id in self.handlers.items():
            ref.unwatch(handler_id)


class Battery(gtk.Box):
    __gtype_name__ = "BatteryApplet"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("battery", "bar-applet")
        )
        upower = get_upower()
        self.icon = widget.Icon(upower.battery_icon)
        self.label = gtk.Label(
            label="0%",
            css_classes=("battery-percentage",)
        )
        self.append(self.icon)
        self.append(self.label)
        self.handler_id = upower.watch("changed", self.update)
        self.settings_handler = Settings().watch(
            "always_show_battery", self.update
        )
        self.update()

    def destroy(self) -> None:
        self.icon.destroy()
        get_upower().unwatch(self.handler_id)
        Settings().unwatch(self.settings_handler)

    def update(self, *args: t.Any) -> None:
        settings = Settings()
        upower = get_upower()

        is_battery_connected = upower.is_battery and upower.is_present
        is_low_charge = (upower.percentage or 0) < 99
        is_not_charging = upower.state not in {
            BatteryState.CHARGING,
            BatteryState.FULL_CHARGED
        }

        is_visible = is_battery_connected and (
            settings.get("always_show_battery")
            or is_low_charge
            or is_not_charging
        )
        if not is_visible:
            self.set_visible(False)
            return
        else:
            self.set_visible(True)

        is_critical = (
            upower.battery_level == BatteryLevel.CRITICAL
            or upower.percentage <= 10
        )
        toggle_css_class(self, "critical", is_critical)

        percent = f"{round(upower.percentage)}%"
        self.label.set_label(percent)
        self.set_tooltip_text(percent)


class Applet(widget.Icon):
    __gtype_name__ = "Applet"

    def __init__(
        self,
        name: str,
        icon: str | Ref[str],
        on_click: t.Callable[[], None],
        on_wheel_click: t.Callable[[], None] | None = None
    ) -> None:
        super().__init__(
            icon=icon,
            css_classes=("applet",)
        )
        self.set_tooltip_text(name.capitalize())

        self.click_gesture = gtk.GestureClick.new()
        self.click_gesture.set_button(0)
        self.gesture_conn = (
            self.click_gesture.connect("released", self.on_click_released)
        )
        self.add_controller(self.click_gesture)

        self.on_click = on_click
        self.on_wheel_click = on_wheel_click

    def on_click_released(
        self,
        gesture: gtk.GestureClick,
        n_press: int,
        x: int,
        y: int
    ) -> None:
        button_number = gesture.get_current_button()
        if button_number == gdk.BUTTON_PRIMARY:
            self.on_click()
        elif button_number == gdk.BUTTON_MIDDLE and self.on_wheel_click:
            self.on_wheel_click()

    def destroy(self) -> None:
        self.click_gesture.disconnect(self.gesture_conn)
        self.remove_controller(self.click_gesture)
        super().destroy()


class BluetoothApplet(Applet):
    __gtype_name__ = "BluetoothApplet"

    def __init__(self) -> None:
        self.bluetooth = bluetooth.get_default()
        super().__init__(
            "bluetooth",
            "bluetooth_disabled",
            lambda: open_settings("bluetooth")
        )
        self.on_update()
        self.handler = self.bluetooth.connect("notify", self.on_update)

    def destroy(self) -> None:
        self.bluetooth.disconnect(self.handler)
        super().destroy()

    def on_update(self, *args: t.Any) -> None:
        is_connected = self.bluetooth.get_is_connected()
        is_powered = self.bluetooth.get_is_powered()
        if is_connected:
            self.set_label("bluetooth_connected")
        elif is_powered:
            self.set_label("bluetooth")
        else:
            self.set_label("bluetooth_disabled")


class BrightnessApplet(Applet):
    __gtype_name__ = "BrightnessApplet"

    def __init__(self) -> None:
        manager = get_backlight_manager()
        self.manager = manager
        super().__init__(
            "brightness",
            manager.devices[0].icon if manager.devices else "",
            self.open_brightness_menu
        )
        if not manager.devices:
            self.initialized = False
            self.set_visible(False)
        else:
            self.device = BacklightDeviceView(manager.devices[0])
            self.initialized = True
            self.scroll = gtk.EventControllerScroll.new(
                gtk.EventControllerScrollFlags.VERTICAL
            )
            self.scroll_handler = self.scroll.connect(
                "scroll", self.on_scroll
            )
            self.add_controller(self.scroll)

            self.device_handler = self.device.watch(
                "changed-external", self.update_tooltip
            )
            self.update_tooltip()

    def update_tooltip(self, *args: t.Any) -> None:
        if not self.manager.devices:
            return

        device = self.device
        current = device.brightness
        max_brightness = device.max_brightness

        value = current / max_brightness * 100
        self.set_tooltip_text(f"Brightness: {round(value)}%")

    def destroy(self) -> None:
        if self.initialized:
            self.remove_controller(self.scroll)
            self.scroll.disconnect(self.scroll_handler)
            self.device.unwatch(self.device_handler)
        super().destroy()

    def open_brightness_menu(self) -> None:
        toggle_window("brightness")

    def on_scroll(
        self,
        controller: gtk.EventControllerScroll,
        dx: float,
        dy: float
    ) -> None:
        if not self.manager.devices:
            return

        device = self.device
        current = device.brightness
        max_brightness = device.max_brightness
        new = 5 / 100 * max_brightness * dy * -1 + current
        device.set_brightness(
            max(min(int(new), max_brightness), 1)
        )


class AudioApplet(Applet):
    __gtype_name__ = "AudioApplet"

    def __init__(
        self,
        icon: Ref[str] | str,
        volume: Ref[float],
        volume_muted: Ref[bool]
    ) -> None:
        self.volume = volume
        self.volume_muted = volume_muted
        super().__init__(
            "volume",
            icon,
            self.open_audio_menu,
            self.open_pavucontrol
        )
        self.scroll = gtk.EventControllerScroll.new(
            gtk.EventControllerScrollFlags.VERTICAL
        )
        self.scroll_handler = self.scroll.connect(
            "scroll", self.on_scroll
        )
        self.add_controller(self.scroll)

        self.volume_handler = self.volume.watch(
            self.update_tooltip
        )
        self.update_tooltip()
        self._last_scroll = 0.0

    def on_click_released(
        self,
        gesture: gtk.GestureClick,
        n_press: int,
        x: int,
        y: int
    ) -> None:
        button_number = gesture.get_current_button()
        if button_number == gdk.BUTTON_PRIMARY:
            self.on_click()
        elif button_number == gdk.BUTTON_MIDDLE and self.on_wheel_click:
            self.on_wheel_click()
        elif button_number == gdk.BUTTON_SECONDARY:
            self.volume_muted.value = not self.volume_muted.value

    def update_tooltip(self, *args: t.Any) -> None:
        self.set_tooltip_text(f"Volume: {int(self.volume.value)}%")

    def destroy(self) -> None:
        self.remove_controller(self.scroll)
        self.scroll.disconnect(self.scroll_handler)
        self.volume.unwatch(self.volume_handler)
        super().destroy()

    def open_pavucontrol(self) -> None:
        launch_detached("pavucontrol")

    def open_audio_menu(self) -> None:
        toggle_window("audio")

    def on_scroll(
        self,
        controller: gtk.EventControllerScroll,
        dx: float,
        dy: float
    ) -> None:
        now = perf_counter()
        if self._last_scroll < now - 0.055:
            self._last_scroll = now
            new = 5 * max(min(dy, 1), -1) * -1 + self.volume.value
            self.volume.value = max(min(new, 100.0), 1.0)


class MicApplet(AudioApplet):
    __gtype_name__ = "MicApplet"

    def __init__(self) -> None:
        super().__init__(
            audio.mic_icon,
            audio.mic_volume,
            audio.mic_muted
        )

        self.ref_handlers: dict[Ref[t.Any], int] = {
            audio.microphones: audio.microphones.watch(
                self.on_mics_changed
            )
        }
        self.on_mics_changed(audio.microphones.value)

    def on_mics_changed(self, new_list: set[t.Any]) -> None:
        self.set_visible(len(new_list) > 0)

    def destroy(self) -> None:
        for ref, handler in self.ref_handlers.items():
            ref.unwatch(handler)
        super().destroy()

    def open_audio_menu(self) -> None:
        toggle_window("mics")


class Applets(gtk.Box):
    __gtype_name__ = "BarApplets"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("applets", "bar-applet"),
            valign=gtk.Align.CENTER
        )

        self.children = (
            MicApplet(),
            AudioApplet(
                audio.volume_icon,
                audio.volume,
                audio.volume_muted
            ),
            BluetoothApplet(),
            Applet(
                "wifi",
                get_network().icon,
                lambda: open_settings("network")
            ),
            BrightnessApplet(),
        )
        for child in self.children:
            if isinstance(child, Applet):
                self.append(child)

    def destroy(self) -> None:
        for child in self.children:
            child.destroy()
            self.remove(child)


class OpenWindow(gtk.Button):
    __gtype_name__ = "OpenWindowButton"

    def __init__(
        self,
        icon: str,
        tooltip: str,
        window_name: str,
        css_classes: tuple[str, ...] = ()
    ) -> None:
        self.window_name = window_name
        super().__init__(
            css_classes=css_classes,
            child=widget.Icon(icon),
            tooltip_text=tooltip,
            valign=gtk.Align.CENTER
        )
        self.conn_id = self.connect("clicked", self.on_clicked)

    def on_clicked(self, *args: t.Any) -> None:
        toggle_window(self.window_name)

    def destroy(self) -> None:
        self.disconnect(self.conn_id)


class ModulesLeft(gtk.Box):
    __gtype_name__ = "BarModulesLeft"

    def __init__(
        self,
        monitor: gdk.Monitor,
        monitor_id: int
    ) -> None:
        super().__init__(
            css_classes=("modules-left",),
            valign=gtk.Align.CENTER
        )
        self.children = (
            OpenWindow(
                "search",
                "Apps Menu",
                "apps_menu",
                ("open-apps-menu", "icon-tonal")
            ),
            OpenWindow(
                "info_i",
                "Info",
                "info",
                ("open-info-menu", "icon-tonal")
            ),
            OpenWindow(
                "ad_group",
                "Windows",
                "clients",
                ("open-clients-menu", "icon-tonal")
            ),
            Player(),
        )
        for child in self.children:
            self.append(child)

    def destroy(self) -> None:
        for child in self.children:
            child.destroy()
            self.remove(child)


class ModulesCenter(gtk.Box):
    __gtype_name__ = "BarModulesCenter"

    def __init__(
        self,
        monitor: gdk.Monitor,
        monitor_id: int
    ) -> None:
        super().__init__(
            css_classes=("modules-center",),
            valign=gtk.Align.CENTER
        )
        self.children = (
            Workspaces(monitor, monitor_id),
        )
        for child in self.children:
            self.append(child)

    def destroy(self) -> None:
        for child in self.children:
            child.destroy()
            self.remove(child)


class NetworkTraffic(gtk.Box):
    __gtype_name__ = "NetworkTraffic"

    def __init__(self) -> None:
        super().__init__(
            css_classes=("bar-applet", "network-speed"),
            valign=gtk.Align.CENTER,
            orientation=gtk.Orientation.HORIZONTAL,
            halign=gtk.Align.CENTER,
            hexpand=False
        )
        self.settings = Settings()
        self.last_rx = 0
        self.last_tx = 0
        self.timer_id = None

        self.download_box = gtk.Box(
            css_classes=("download-box",),
            orientation=gtk.Orientation.HORIZONTAL,
            hexpand=True
        )
        self.download_icon = widget.Icon(
            "download",
            css_classes=("download-icon",),
        )
        self.download_label = gtk.Label(
            label="0 Kb/s",
            css_classes=("download-label",),
            hexpand=True
        )

        self.upload_box = gtk.Box(
            css_classes=("upload-box",),
            orientation=gtk.Orientation.HORIZONTAL,
            hexpand=True
        )
        self.upload_icon = widget.Icon(
            "upload",
            css_classes=("upload-icon",)
        )
        self.upload_label = gtk.Label(
            label="0 Kb/s",
            css_classes=("upload-label",),
            hexpand=True
        )

        self.download_box.append(self.download_icon)
        self.download_box.append(self.download_label)

        self.upload_box.append(self.upload_icon)
        self.upload_box.append(self.upload_label)

        self.append(self.download_box)
        self.append(self.upload_box)

        self.setting_handler = self.settings.watch(
            "show_network_speed", self.on_setting_changed
        )

    def get_bytes(self):
        rx = 0
        tx = 0

        try:
            with open("/proc/net/dev") as f:
                lines = f.readlines()[2:]
                for line in lines:
                    data = line.split()
                    if data[0].strip(":") == "lo": continue
                    rx += int(data[1])
                    tx += int(data[9])
        except Exception:
            pass

        return rx, tx

    def format_speed(self, speed):
        if speed > 1024 * 1024:
            return f"{speed / 1024 / 1024:.1f} Mb/s"
        if speed > 1024:
            return f"{speed / 1024:.0f} Kb/s"

        return f"{speed} B/s"

    def update(self):
        rx, tx = self.get_bytes()

        if self.last_rx == 0:
            self.last_rx = rx
            self.last_tx = tx
            return True

        rx_speed = rx - self.last_rx
        tx_speed = tx - self.last_tx

        self.last_rx = rx
        self.last_tx = tx

        self.download_label.set_label(self.format_speed(rx_speed))
        self.upload_label.set_label(self.format_speed(tx_speed))
        return True

    def on_setting_changed(self, value: bool) -> None:
        self.set_visible(value)
        if value:
            if self.timer_id is None:
                self.last_rx = 0
                self.last_tx = 0
                self.update()
                self.timer_id = glib.timeout_add_seconds(1, self.update)
        else:
            if self.timer_id:
                glib.source_remove(self.timer_id)
                self.timer_id = None

    def destroy(self, *args) -> None:
        self.settings.unwatch(self.setting_handler)
        if self.timer_id:
            glib.source_remove(self.timer_id)
            self.timer_id = None


class ModulesRight(gtk.Box):
    __gtype_name__ = "BarModulesRight"

    def __init__(
        self,
        monitor: gdk.Monitor,
        monitor_id: int
    ) -> None:
        super().__init__(
            css_classes=("modules-right",),
            valign=gtk.Align.CENTER
        )
        self.children = (
            NetworkTraffic(),
            KeyboardLayout(),
            Battery(),
            OpenWindow(
                "browse",
                "System Tray",
                "tray",
                ("open-tray", "bar-applet")
            ),
            OpenWindow(
                "content_paste",
                "Clipboard",
                "cliphist",
                ("open-cliphist", "bar-applet")
            ),
            Applets(),
            Clock(),
            OpenWindow(
                "space_dashboard",
                "Sidebar",
                "sidebar",
                ("open-sidebar", "icon-tonal")
            )
        )
        for child in self.children:
            self.append(child)

    def destroy(self) -> None:
        for child in self.children:
            child.destroy()
            self.remove(child)


edges = (
    layer_shell.Edge.TOP,
    layer_shell.Edge.LEFT,
    layer_shell.Edge.RIGHT
)


class Bar(widget.LayerWindow):
    __gtype_name__ = "Bar"

    def __init__(
        self,
        application: gtk.Application,
        monitor: gdk.Monitor,
        monitor_id: int
    ) -> None:
        super().__init__(
            application,
            height=1,
            anchors={
                "top": True,
                "left": True,
                "right": True
            },
            exclusive=True,
            monitor=monitor,
            css_classes=("bar",),
            name="bar",
            layer=layer_shell.Layer.OVERLAY
        )

        self.monitor = monitor
        self.monitor_id = monitor_id
        self.center_box = gtk.CenterBox(
            start_widget=ModulesLeft(monitor, monitor_id),
            center_widget=ModulesCenter(monitor, monitor_id),
            end_widget=ModulesRight(monitor, monitor_id)
        )

        self.ref_handlers: dict[Ref[t.Any], int] = {
            hyprland.active_client: hyprland.active_client.watch(
                self.update_hidden
            ),
            _opened_windows: _opened_windows.watch(self.update_hidden)
        }
        self.settings = Settings()
        self.settings_handlers = {
            self.settings.watch(
                "old_fullscreen_behavior", self.update_hidden, False
            ),
            self.settings.watch(
                "floating_bar", self.change_floating, True
            ),
            self.settings.watch(
                "hyprland.gaps_out", self.change_floating, False
            )
        }
        self.old_fullscreen_state: bool | None = None
        self.visible_timeout: int = -1

        self.set_child(self.center_box)
        self.show()
        if __debug__:
            weakref.finalize(self, lambda: logger.debug("Bar finalized"))
        self.update_hidden()

    def on_gaps_out(self, value: int) -> None:
        self.change_floating(self.settings.get("floating_bar"))

    def change_floating(self, value: bool) -> None:
        toggle_css_class(self, "floating", value)
        if value:
            gap = self.settings.get("hyprland.gaps_out")
            for edge in edges:
                layer_shell.set_margin(self, edge, gap)
        else:
            for edge in edges:
                layer_shell.set_margin(self, edge, 0)

    def update_hidden(self, *args: t.Any) -> None:
        if self.visible_timeout != -1:
            glib.source_remove(self.visible_timeout)
            self.visible_timeout = -1

        old_fullscreen = Settings().get("old_fullscreen_behavior")
        if old_fullscreen:
            if self.old_fullscreen_state:
                return
            layer_shell.set_layer(
                self, layer_shell.Layer.TOP
            )
            self.set_visible(False)
            self.set_visible(True)
            self.old_fullscreen_state = True
            return
        elif self.old_fullscreen_state is True:
            layer_shell.set_layer(
                self, layer_shell.Layer.OVERLAY
            )
            self.old_fullscreen_state = False
            self.set_visible(False)
            self.set_visible(True)

        monitor_name = self.monitor.get_connector()
        monitor_id = hyprland.monitor_ids.value.get(
            monitor_name, self.monitor_id
        )
        active_client = hyprland.active_client.value.get(monitor_id)
        set_visible = True
        if (
            len(_opened_windows.value) > 0
            or active_client is None
        ):
            set_visible = True
        else:
            set_visible = not active_client.fullscreen

        if set_visible is True:
            self.set_visible(True)
        else:
            weak_self = weakref.ref(self)

            def hide() -> None:
                self = weak_self()
                if not self:
                    return
                self.set_visible(False)
                self.visible_timeout = -1

            self.visible_timeout = glib.timeout_add(
                250, hide
            )

    def destroy(self) -> None:
        box = self.center_box
        start_widget = box.get_start_widget()
        center_widget = box.get_center_widget()
        end_widget = box.get_end_widget()
        if isinstance(start_widget, ModulesLeft):
            start_widget.destroy()
        if isinstance(center_widget, ModulesCenter):
            center_widget.destroy()
        if isinstance(end_widget, ModulesRight):
            end_widget.destroy()
        box.set_start_widget(None)
        box.set_center_widget(None)
        box.set_end_widget(None)
        self.set_child(None)
        self.close()
        for ref, handler in self.ref_handlers.items():
            ref.unwatch(handler)
        super().destroy()


class Corners:
    def __init__(
        self,
        application: gtk.Application,
        monitor: gdk.Monitor
    ) -> None:
        self.settings = Settings()
        self.decoration = self.settings.get_view_for("hyprland.decoration")
        self.application = application
        self.monitor = monitor

        self.windows: list[widget.LayerWindow] = []
        self.corners: list[widget.RoundedCorner] = []

        self.handlers = (
            self.settings.watch(
                "corners", self.update_visible, True
            ),
            self.settings.watch(
                "floating_bar", self.update_visible, False
            ),
            self.settings.watch(
                "hyprland.gaps_out", self.update_rounding, False
            ),
            self.decoration.watch(
                "rounding", self.update_rounding, False
            )
        )

    def get_radius(self) -> int:
        gap = self.settings.get("hyprland.gaps_out")
        rounding = self.decoration.get("rounding")
        return int(gap + rounding)

    def update_rounding(self, *args: t.Any) -> None:
        if self.windows:
            self.destroy_windows()
        self.create_windows()

    def create_windows(self) -> None:
        for is_on_left in (True, False):
            window = widget.LayerWindow(
                application=self.application,
                monitor=self.monitor,
                anchors={
                    "top": True,
                    "left": is_on_left,
                    "right": not is_on_left
                },
                css_classes=("transparent",),
                name="corner"
            )
            self.windows.append(window)

            corner = widget.RoundedCorner(
                f"top-{"left" if is_on_left else "right"}",
                radius=self.get_radius()
            )
            self.corners.append(corner)
            window.set_child(corner)

            self.application.add_window(window)

            window.show()
            surface = window.get_surface()
            if surface:
                surface.set_input_region(
                    dummy_region  # type: ignore[arg-type]
                )

    def destroy(self) -> None:
        self.destroy_windows()
        for handler in self.handlers:
            self.settings.unwatch(handler)

    def destroy_windows(self) -> None:
        for window in self.windows:
            window.destroy()
        self.windows.clear()
        self.corners.clear()

    def update_visible(self, *args: t.Any) -> None:
        value = (
            not self.settings.get("floating_bar")
            and self.settings.get("corners")
        )
        if value and not self.windows:
            self.create_windows()
        elif self.windows:
            self.destroy_windows()
