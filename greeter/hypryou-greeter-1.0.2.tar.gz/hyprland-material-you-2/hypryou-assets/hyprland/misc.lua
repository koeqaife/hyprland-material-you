hl.config({
    misc = {
        animate_manual_resizes = false,
        animate_mouse_windowdragging = false,
        enable_swallow = false,
        swallow_regex = "(foot|kitty|allacritty|Alacritty)",

        mouse_move_enables_dpms = true,
        key_press_enables_dpms = true,

        session_lock_xray = true,
        disable_hyprland_logo = true,
        disable_splash_rendering = true,
        on_focus_under_fullscreen = 2,
        allow_session_lock_restore = true,
        lockdead_screen_delay = 5000,

        enable_anr_dialog = true,
        anr_missed_pings = 3,

        initial_workspace_tracking = false,
    },
    input = {
        kb_options = "",
    }
})
